CREATE DATABASE IF NOT EXISTS online_store;
CREATE USER IF NOT EXISTS 'test'@'%' IDENTIFIED BY 'test';
GRANT ALL PRIVILEGES ON online_store.* TO 'test'@'%';

CREATE DATABASE IF NOT EXISTS online_store_test;
CREATE USER IF NOT EXISTS 'test'@'%' IDENTIFIED BY 'test';
GRANT ALL PRIVILEGES ON online_store_test.* TO 'test'@'%';